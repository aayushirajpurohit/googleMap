import React from "react";

//👇🏻 app screens
// import Login from "./screens/Login";
import Messaging from "../screens/messaging/Messaging";
import Chat from "../screens/chat/Chat";

//👇🏻 React Navigation configurations

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Splash from "../screens/splash/Splash";

const Stack = createNativeStackNavigator();

export default function NavigationStack() {
    return (
     
            <Stack.Navigator initialRouteName='Splash'>
                <Stack.Screen
                    name='Splash'
                    component={Splash}
                    options={{ headerShown: false }}
                />

                <Stack.Screen
                    name='Chat'
                    component={Chat}
                    options={{
                      
                        headerShown: false,
                    }}
                />
                <Stack.Screen name='Messaging' component={Messaging} />
            </Stack.Navigator>
      
    );
}